from dataclasses import dataclass

import datetime

@dataclass
class Drill:
    """It is a drilling dictionary for a well"""

    start        : datetime.date = None
    end          : datetime.date = None

    layer        : str = None
    depth        : float = None

    layer_target : str = None
    depth_target : float = None