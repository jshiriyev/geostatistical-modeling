from .petrodata import wellbore
from .petrodata import reservoir

from . import onepager