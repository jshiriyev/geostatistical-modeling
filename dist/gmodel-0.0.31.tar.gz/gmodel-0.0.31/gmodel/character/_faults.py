from dataclasses import dataclass

@dataclass
class Fault:
    """"""
    name: str
    index: int = None
    field: str = None