import unittest

import numpy as np

if __name__ == "__main__":
    import dirsetup

from wells import Slot

class TestWellSlot(unittest.TestCase):

    def geometry(self):
        pass

    def singlephase(self):
        pass

    def multiphase(self):
        pass

if __name__ == "__main__":

    unittest.main()
