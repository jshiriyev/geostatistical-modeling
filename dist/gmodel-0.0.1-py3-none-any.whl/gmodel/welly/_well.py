from dataclasses import dataclass

import numpy

from ._survey import Survey

@dataclass
class Well:

    name         : str = None
    field        : str = None

    status       : str = "prospect"

    @property
    def slot(self):
        return self._slot

    @slot.setter
    def slot(self,value):
        self._slot = Slot(**value)

    @property
    def drilling(self):
        return self._drilling

    @drilling.setter
    def drilling(self,value):
        self._drilling = Drilling(**value)

    @property
    def survey(self):
        return self._survey

    @survey.setter
    def survey(self,value):
        self._survey = Survey(**value)

    @property
    def perf(self):
        return self._perf

    @perf.setter
    def perf(self,value):
        self._perf = Perforation(**value)

@dataclass
class Slot:
    """It is a slot dictionary for a well."""
    index 		 : int = None

    platform 	 : str = None

    xhead 		 : float = 0.0
    yhead 		 : float = 0.0
    datum 		 : float = 0.0

@dataclass
class Drilling:
    """It is a drilling dictionary for a well"""

    start        : datetime.date = None
    end          : datetime.date = None

    layer        : str = None
    depth        : float = None

    layer_target : str = None
    depth_target : float = None

@dataclass
class Perforation:
    """It is a perforation dictionary for a perf in a well."""

    date        : datetime.date = None

    layer       : str = None

    interval    : str = None

    perf_type   : str = None

    @staticmethod
    def interval_string_to_list(value:str,delimiter="-",decsep="."):

        depths = value.split(delimiter)

        depths = [float(depth.replace(decsep,'.')) for depth in depths]

        if len(depths)==1:
            depths.append(None)

        return depths
