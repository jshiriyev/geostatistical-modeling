from dataclasses import dataclass

@dataclass
class Target:
	"""It is a Target dictionary for a Drill"""

	layer 		 : str = None
	depth 		 : float = None

if __name__ == "__main__":

	pass