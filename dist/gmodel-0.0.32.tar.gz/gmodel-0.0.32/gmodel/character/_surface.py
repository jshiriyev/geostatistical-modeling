from ._items import Zone

class Surface(Zone):
    """It is surface for the zone. It should allow adding stock and modifying surface x,y,z"""

    def __init__(self):

        pass